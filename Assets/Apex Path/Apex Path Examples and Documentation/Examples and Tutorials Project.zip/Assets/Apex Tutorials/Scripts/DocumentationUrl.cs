﻿namespace Apex.Tutorials
{
    using UnityEngine;

    [AddComponentMenu("Apex/Tutorials/Documentation Url")]
    public class DocumentationUrl : MonoBehaviour
    {
        public string url;
    }
}
